
# Description
The package includes the code and datasets used in the paper "Yuanyu Wan, Bo Xue, Lijun Zhang. Projection-free Online Learning in Dynamic Environments. AAAI 2021.".

# How to run?
1.Install the PROPACK package, which is used to compute the top-1 SVD and already included in this package. The code should work on both Windows and Linux system. For more information about PROPACK, please refer to http://sun.stanford.edu/~rmunk/PROPACK/.
2.Run demo.m for the experiment of online matrix completion in dynamic environments. Please refer to the paper for detailed setup.

# Other Specific Functions
Multi_IOCG.m -> the Multi-OCG+ algorithm in the paper.
RFTL.m -> the RFTL algorithm [1].
CBCE_RFTL.m -> the combination of CBCE [2] and RFTL [1].
pro_simplex.m -> projection onto the simplex

# Datasets are downloaded from https://grouplens.org/datasets/movielens/100k/. We only modified the format of the orginal datasets to make them easy to load and simulate the dynamic environments.

# References
[1] Jun, K.-S.; Orabona, F.; Wright, S.; and Willett, R. 2017. Improved strongly adaptive online learning using coin betting. In Proceedings of the 20th International Conference on Artificial Intelligence and Statistics, 943–951.
[2] Hazan, E. 2016. Introduction to online convex optimization. Foundations and Trends in Optimization 2(3–4): 157–325.



