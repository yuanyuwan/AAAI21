function s = pro_simplex(s,tau)
%sum(s) <= tau already lies in the simplex
if sum(s) > tau
    s = s';
    cssv = cumsum(s);
    rho = (s .* (1:length(s)) > (cssv - tau));
    rho = find(rho, 1, 'last');
    theta = (cssv(rho) - tau) ./ rho;
    s = max(s - theta,0);
end