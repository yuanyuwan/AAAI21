clear all

load('./movie_lens_3.mat')
m = max(data(:,1)); %Row Number
n = max(data(:,2)); %Coulmn Number
num_data = length(data);
bs = 100; %Batch Size
T = num_data/bs;

maxNorm = 5000;
ccc = 1e4;
eta_c=ccc;%Seleted by Grid Search

%Parameters of meta-algorithm
N=floor(log2(T))+1;
tau=zeros(N,1);
R=zeros(N,1);
C=ones(N,1);
W_m=ones(N,1);
w=zeros(N,1);
p=zeros(N,1);

X=zeros(m,n);
for i=1:N
    tau(i)=pow2(i-1);
end

loss_meta=zeros(T,1);
time_meta=zeros(T,1);
%Parameters of sub-algorithm
eta=zeros(N,1);
for i=1:N
    eta(i)=eta_c/sqrt(tau(i));
end

XS=zeros(m,n,N);
G=zeros(m,n,N);
N_m = 1;
tic
for i=1:T
    %Compute the number of active sub-algorithms
    if N_m<N && mod(i,tau(N_m+1))==0
        N_m=N_m+1;
    end
    
    %Restart some sub-algorithms
    flag=mod(i,tau)==0;
    R(flag)=0;
    C(flag)=1;
    W_m(flag)=1;
    XS(:,:,flag)=0;
    G(:,:,flag)=0;
    w=(R./C).*W_m;
    s_w=norm(max(w,0),1);
    if s_w==0
        p=ones(N_m,1)/N_m;
    else
        p=max(w,0)./s_w;
    end
    
    %Generate a decision of meta-algorithm
    X=0;
    for j=1:N_m
        X=X+XS(:,:,j)*p(j);
    end
    
    %Observe loss and update parameters
    f_meta=0;
    f_subs=zeros(N,1);
    for j = (i-1)*bs+1:i*bs
        index_m = data(j,1);
        index_n = data(j,2);
        v = data(j,3);
        f_meta = f_meta + abs(X(index_m,index_n) - v);
        for jj = 1:N
            f_subs(jj) = f_subs(jj) + abs(XS(index_m,index_n,jj)-v);
            G(index_m,index_n,jj) = G(index_m,index_n,jj) + sign(XS(index_m,index_n,jj)-v);
        end
        
    end
    
    loss_meta(i)=f_meta;
    
    f_meta = f_meta/1000;
    f_subs = f_subs./1000;
    
    for j=1:N_m
        if w(j)>0
            R(j)=R(j)+f_meta-f_subs(j);
            C(j)=C(j)+1;
            W_m(j)=W_m(j)+(f_meta-f_subs(j))*w(j);
        else
            R(j)=R(j)+max(f_meta-f_subs(j),0);
            C(j)=C(j)+1;
            W_m(j)=W_m(j)+max(f_meta-f_subs(j),0)*w(j);
        end
        
        Xj = -0.5*eta(j)*G(:,:,j);
        %Projection Step
        [U,S,V] = svd(Xj,'econ');
        S=diag(pro_simplex(diag(S),maxNorm));
        XS(:,:,j)=U*S*V';
    end
    time_meta(i) = toc;
end
toc
save('./Result/CBCE_RFTL.mat','loss_meta','time_meta')


