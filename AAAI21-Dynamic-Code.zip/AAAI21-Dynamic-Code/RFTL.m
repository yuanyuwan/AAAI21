clear all

load('./movie_lens_3.mat')
m = max(data(:,1)); %Row Number
n = max(data(:,2)); %Coulmn Number
num_data = length(data);
bs = 100; %Batch Size

T = num_data/bs;
maxNorm = 5000;
ccc = 1e4;
eta_c=ccc;%Seleted by Grid Search

X=zeros(m,n);

loss=zeros(T,1);
time_r = zeros(T,1);
eta=eta_c/sqrt(T);

G=zeros(m,n);
tic
for i=1:T
    %Observe loss and update parameters
    f_meta=0;
    for j = (i-1)*bs+1:i*bs
        index_m = data(j,1);
        index_n = data(j,2);
        v = data(j,3);
        f_meta = f_meta + abs(X(index_m,index_n) - v);
        G(index_m,index_n) = G(index_m,index_n) + sign(X(index_m,index_n)-v); 
    end
    
    loss(i)=f_meta;
    
    X = -0.5*eta*G(:,:);
    %Projection Step
    [U,S,V] = svd(X,'econ');
    S=diag(pro_simplex(diag(S),maxNorm));
    X=U*S*V';
    time_r(i) = toc;
end
toc

save('./Result/RFTL.mat','loss', 'time_r')
