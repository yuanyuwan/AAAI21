%% Run each algorithm
RFTL;
CBCE_RFTL;
Multi_IOCG;

%% Create the figures
load('./Result/RFTL.mat')
figure(1)
hold on
plot(cumsum(loss))

figure(2)
hold on
plot(time_r)

load('./Result/CBCE_RFTL.mat')
figure(1)
hold on
plot(cumsum(loss_meta))

figure(2)
hold on
plot(time_meta)

load('./Result/Multi_IOCG.mat')
figure(1)
hold on
plot(cumsum(loss_meta))

figure(2)
hold on
plot(time_meta)