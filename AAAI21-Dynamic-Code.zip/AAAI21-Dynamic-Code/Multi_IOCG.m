clear all

load('./movie_lens_3.mat')
m = max(data(:,1)); %Row Number
n = max(data(:,2)); %Coulmn Number
num_data = length(data);
bs = 100; %Batch Size
T = num_data/bs;
sss = 0.1;
ss = sss/sqrt(T); %Seleted by Grid Search

maxNorm = 5000;
ccc = 1e4;
eta_c=ccc;%Seleted by Grid Search

%Parameters of meta-algorithm
N=floor(log2(T))+1;
tau=zeros(N,1);
p=zeros(N,1);
X=zeros(m,n);
for i=1:N
    tau(i)=pow2(i-1);
    p(i)=1.0/(i*(i+1));
end
p=p./sum(p);
loss_meta=zeros(T,1);
time_meta=zeros(T,1);

%Parameters of sub-algorithm
K=4;
eta=zeros(N,1);
for i=1:N
    eta(i)=eta_c/sqrt(tau(i));
end

XS=zeros(m,n,N);
G=zeros(m,n,N);
tic
for i=1:T
    %Restart some sub-algorithms
    flag=mod(i,tau)==1;
    flag(1) = 1;
    G(:,:,flag)=0;
    XS(:,:,flag)=0;
    
    %Generate a decision of meta-algorithm
    X=0;
    for j=1:N
        X=X+XS(:,:,j)*p(j);
    end
    
    %Observe loss and update parameters
    f_meta=0;
    f_subs=zeros(N,1);
    for j = (i-1)*bs+1:i*bs
        index_m = data(j,1);
        index_n = data(j,2);
        v = data(j,3);
        f_meta = f_meta + abs(X(index_m,index_n) - v);
        for jj = 1:N
            f_subs(jj) = f_subs(jj) + abs(XS(index_m,index_n,jj)-v);
            G(index_m,index_n,jj) = G(index_m,index_n,jj) + sign(XS(index_m,index_n,jj)-v);
        end
        
    end
    
    loss_meta(i)=f_meta;
    
    for j=1:N
        p(j) = p(j)*exp(-ss*f_subs(j));
        Xj = XS(:,:,j);
        Xj_k = [];
        for k = 1:K
            Xj_k = Xj;
            %Iterative Linear Optimization Steps
            DF = eta(j).*G(:,:,j) + 2.*Xj;
            [u,s,v] = lansvd(-DF, 1, 'L', struct('tol',1e-5));
            V = maxNorm.*u*v';
            Delta = V - Xj;
            flag2 = sum(dot(-DF,Delta));
            if flag2 <= 1e-3
                break;
            end
            sigma = 0.5 * flag2 / sum(dot(Delta,Delta));
            if sigma < 0
                sigma = 0;
            elseif sigma > 1
                sigma = 1;
            end
            Xj = Xj + sigma .* Delta;
        end
        XS(:,:,j) = Xj_k;
    end
    p=p./sum(p);
    time_meta(i) = toc;
end
toc

save('./Result/Multi_IOCG.mat','loss_meta','time_meta')
